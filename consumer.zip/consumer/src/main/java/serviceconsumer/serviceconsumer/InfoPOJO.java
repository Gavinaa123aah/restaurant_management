package serviceconsumer.serviceconsumer;

public class InfoPOJO {

    public String name=null;
    public String location=null;
    public String picture=null;

    public String getName(){
        return this.name;
    }

    public void setName(String n){
        this.name=n;
    }

    public String getLocation(){
        return this.location;
    }

    public void setLocation(String l){
        this.location=l;
    }

    public String getPicture(){
        return this.picture;
    }

    public void setPicture(String p){
        this.picture=p;
    }

}
