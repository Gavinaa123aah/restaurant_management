package serviceconsumer.serviceconsumer.keyquaryDAO;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.springframework.stereotype.Service;
import serviceconsumer.serviceconsumer.InfoPOJO;

import java.util.ArrayList;
import java.util.List;

//远程获取并处理spark的数据
@Service
public class DisQuaryDao {

    private static final String filepath="";
    public SparkSession getSession(){

        //建立与spark服务端的会话
        SparkSession session=SparkSession.builder().appName("keyquary").master("spark://47.95.232.128:7077").getOrCreate();
        return session;
    }

    public String xxx(String key){
        SparkSession spark=getSession();
        //获取指定数据文件
        Dataset<Row> d1=spark.read().json("file:///home/hjy/bigdata/test1.json");
//        String cond="name="+key;
//        d1.select("name","location","picture").show(3);
//        // 生成schema
//        List<StructField> fields = new ArrayList<>();
//        fields.add(DataTypes.createStructField("name", DataTypes.StringType, true));
//        fields.add(DataTypes.createStructField("location", DataTypes.StringType, true));
//        fields.add(DataTypes.createStructField("picture", DataTypes.StringType, true));
//        StructType schema = DataTypes.createStructType(fields);
//
//        List<InfoPOJO> restaurants = spark.createDataFrame(d2.toJavaRDD(), schema) .as(Encoders.bean(InfoPOJO.class)) .collectAsList();


       return "dfadsf";
    }
}
