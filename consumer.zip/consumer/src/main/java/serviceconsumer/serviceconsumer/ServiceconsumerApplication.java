package serviceconsumer.serviceconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableDiscoveryClient //用于启动服务发现功能，向服务注册中心注册该服务
@EnableFeignClients //用于启动Fegin功能
@SpringBootApplication

public class ServiceconsumerApplication {

    //主入口
    public static void main(String[] args) {
        SpringApplication.run(ServiceconsumerApplication.class, args);
    }
}
