package serviceconsumer.serviceconsumer.outerservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

//Feign功能，用于和其他服务交互，比如下面与QUARY-SERVICE服务通信：
@FeignClient("QUARY-SERVICE")
public interface QuaryServiceInf {

    //下边是QUARY-SERVICE服务提供的接口
    @RequestMapping(value = "/disquary",method= RequestMethod.GET)
    String disquary(@RequestParam(value = "key",required = false,defaultValue = "1") String k);

    @RequestMapping(value = "/vagquary",method= RequestMethod.GET)
    List<String> vagquary();
}
