package serviceconsumer.serviceconsumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import serviceconsumer.serviceconsumer.keyquaryDAO.DisQuaryDao;
import serviceconsumer.serviceconsumer.outerservice.QuaryServiceInf;

import java.util.List;

//接受并处理来自浏览器的http请求
@RestController
public class ServiceConsumerImp {


    @Autowired
    private QuaryServiceInf qs;

    @Autowired
    DisQuaryDao dq;

    //下边俩个是该服务给客户端提供的rest接口，浏览器通过这些接口访问，比如输入http://localhost/keyquary/dis访问下边第一个功能
    @RequestMapping(value = "/keyquary/dis",method = RequestMethod.GET)
    public String disquary(@RequestParam(value="key",required = false,defaultValue = "1") String name){
       return dq.xxx(name);

    }
    @RequestMapping(value = "/keyquary/vag",method = RequestMethod.GET)
    public String vagquary(){
        //该功能需要和QUARY-SERVICE服务交互，调用QuaryServiceInf实例
        List<String> res= qs.vagquary();
        return res.get(1);
    }

}
